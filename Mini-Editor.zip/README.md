# Mini Editor

A lightweight, multi-tab code editor built entirely from scratch in Python and Tkinter — no Electron, no web view, just native desktop widgets and a hand-built syntax highlighting engine.

## Why this exists

Most "build your own editor" tutorials stop at a text box with a Save button. This project goes further: a real regex-based tokenizer for seven languages, a fully modular codebase, custom themed dialogs (because Tkinter's built-in ones don't respect dark mode), and native packaging for both Linux and Windows.

## Features

- **Syntax highlighting** for Python, JavaScript, HTML, CSS, PHP, C#, and C++, via a custom single-pass regex tokenizer (the same general technique CPython's own IDLE editor uses)
- **Multi-tab editing** with per-tab unsaved-change tracking and safe close/quit prompts
- **Dark / light themes** — fully consistent across the editor, dialogs, and file browser
- **Find & Replace** with a case-sensitivity toggle
- **Custom file dialogs** — a themed Open/Save file browser and font picker, built from scratch since Tkinter's native dialogs can't be restyled for dark mode
- **Word-aware Ctrl+Backspace** — deletes whitespace, word, and punctuation runs as separate steps, matching how most code editors handle it
- **Native packaging** — a `.deb` installer for Debian/Ubuntu with full desktop integration, and a Windows `.exe` via PyInstaller

## Architecture

The codebase is split into focused modules instead of one large file:

```
mini_editor/
├── main.py            # entry point, sets up the window and app icon
├── app.py              # TextEditor: top-level orchestrator, tab/file management
├── editor_tab.py       # per-tab widget creation, word-delete, highlight scheduling
├── menu.py             # menu bar and keyboard shortcuts
├── theme.py            # light/dark theming, syntax color palettes
├── dialogs.py          # themed replacements for messagebox and filedialog
├── font_picker.py       # font selection dialog
├── find_replace.py      # Find & Replace dialog
├── make_icon.py          # generates the app icon (Pillow, no external assets)
├── assets/               # generated icon files (.png, .ico)
└── syntax/
    ├── base.py           # generic regex-tokenizer highlighter engine
    ├── python_lang.py
    ├── javascript_lang.py
    ├── html_lang.py
    ├── css_lang.py
    ├── php_lang.py
    ├── csharp_lang.py
    └── cpp_lang.py
```

### The syntax highlighting engine

Rather than writing a bespoke highlighter per language, `syntax/base.py` defines a generic `Highlighter` class. Each language module just supplies an ordered list of `(tag_name, regex_pattern)` pairs — comments, strings, keywords, numbers, and so on. The base class combines them into a single alternation regex with named groups, scans the buffer once, and maps each match straight to a Tkinter tag.

Because it's one linear scan, matches never overlap, so there's no need to manually resolve priority between token types beyond the order they're listed in. Adding a new language means writing one small file with a token list — nothing else in the app needs to change.

### Why custom dialogs instead of `tkinter.messagebox` / `filedialog`

Tkinter's built-in dialogs are drawn by native/platform code and completely ignore any theme or widget styling set elsewhere in the app. The moment dark mode is on, a native "Save changes?" popup would show up looking like a jarring light-mode box in the middle of a dark window. `dialogs.py` replaces these with plain `Toplevel` windows styled to match whichever theme is active, including a full custom file browser (with folder navigation and, on Windows, drive switching) in place of the native Open/Save dialogs.

## Running from source

Requires Python 3.8+ with Tk support (`python3-tk` on Debian/Ubuntu if it isn't already installed).

```bash
git clone <your-repo-url>
cd mini_editor
python3 main.py
```

## Installing on Linux (.deb)

```bash
sudo apt install ./mini-editor_1.0.0_all.deb
```
This registers a desktop menu entry, icon, and the `mini-editor` command, and pulls in `python3-tk` automatically as a dependency.

To remove:
```bash
sudo apt remove mini-editor
```

## Building the Windows executable

Must be run on Windows (PyInstaller does not cross-compile):
```
pip install pyinstaller
pyinstaller --onefile --windowed --icon=assets/icon.ico --add-data "assets;assets" --name "MiniEditor" main.py
```
The finished executable is written to `dist/MiniEditor.exe`.

## Known limitations

- The CSS and PHP highlighters use simplified tokenization rather than a full parser — e.g. `a:hover` can mis-tag `a` as a CSS property name. This is an accepted tradeoff for an editor highlighter, not a full language parser.
- The Windows executable is unsigned, so SmartScreen will show an "unrecognized publisher" warning on first run.

## License

MIT
