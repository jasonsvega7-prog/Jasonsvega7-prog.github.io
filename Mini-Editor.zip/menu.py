import tkinter as tk

from syntax import LANGUAGES


def build_menu(app):
    menubar = tk.Menu(app.root)

    file_menu = tk.Menu(menubar, tearoff=0)
    file_menu.add_command(label="New", command=app.new_file, accelerator="Ctrl+N")
    file_menu.add_command(label="Open...", command=app.open_file, accelerator="Ctrl+O")
    file_menu.add_command(label="Save", command=app.save_file, accelerator="Ctrl+S")
    file_menu.add_command(label="Save As...", command=app.save_as)
    file_menu.add_separator()
    file_menu.add_command(label="Close Tab", command=app.close_current_tab, accelerator="Ctrl+W")
    file_menu.add_separator()
    file_menu.add_command(label="Exit", command=app.on_close)
    menubar.add_cascade(label="File", menu=file_menu)

    edit_menu = tk.Menu(menubar, tearoff=0)
    edit_menu.add_command(label="Find & Replace...", command=app.find_replace_window, accelerator="Ctrl+F")
    menubar.add_cascade(label="Edit", menu=edit_menu)

    view_menu = tk.Menu(menubar, tearoff=0)
    view_menu.add_command(label="Toggle Dark/Light Theme", command=app.toggle_dark_mode)
    view_menu.add_command(label="Choose Font...", command=app.choose_font)
    menubar.add_cascade(label="View", menu=view_menu)

    language_menu = tk.Menu(menubar, tearoff=0)
    app.language_var = tk.StringVar(value="Plain Text")
    for display_name, key in LANGUAGES.items():
        language_menu.add_radiobutton(
            label=display_name,
            variable=app.language_var,
            value=display_name,
            command=lambda k=key: app.set_current_tab_language(k),
        )
    menubar.add_cascade(label="Language", menu=language_menu)

    app.root.config(menu=menubar)


def bind_shortcuts(app):
    app.root.bind_all("<Control-n>", lambda e: app.new_file())
    app.root.bind_all("<Control-o>", lambda e: app.open_file())
    app.root.bind_all("<Control-s>", lambda e: app.save_file())
    app.root.bind_all("<Control-w>", lambda e: app.close_current_tab())
    app.root.bind_all("<Control-f>", lambda e: app.find_replace_window())
