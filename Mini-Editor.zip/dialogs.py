import os
import tkinter as tk


def theme_colors(dark_mode):
    if dark_mode:
        return {
            "bg": "#1e1e1e",
            "panel": "#2d2d30",
            "fg": "white",
            "button_bg": "#3c3c3c",
            "button_active": "#555555",
            "select_bg": "#04395e",
            "accent": "#f14c4c",
        }
    return {
        "bg": "white",
        "panel": "#f0f0f0",
        "fg": "black",
        "button_bg": "#f0f0f0",
        "button_active": "#d9d9d9",
        "select_bg": "#cce8ff",
        "accent": "#c42b1c",
    }


def center_on_parent(win, parent):
    win.update_idletasks()
    x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (win.winfo_width() // 2)
    y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (win.winfo_height() // 2)
    win.geometry(f"+{max(x, 0)}+{max(y, 0)}")


def styled_button(parent, text, command, colors, width=11):
    return tk.Button(
        parent, text=text, width=width, command=command,
        bg=colors["button_bg"], fg=colors["fg"],
        activebackground=colors["button_active"], activeforeground=colors["fg"],
        relief="flat", bd=0, highlightthickness=0,
    )


def _make_dialog(app, title, resizable=False):
    colors = theme_colors(app.dark_mode)
    win = tk.Toplevel(app.root)
    win.title(title)
    win.resizable(resizable, resizable)
    win.transient(app.root)
    win.configure(bg=colors["bg"])
    return win, colors


# ================= MESSAGE DIALOGS ================= #
def ask_yes_no_cancel(app, title, message):
    win, colors = _make_dialog(app, title)
    result = {"value": None}

    tk.Label(win, text=message, bg=colors["bg"], fg=colors["fg"],
             wraplength=320, justify="left", padx=24, pady=20).pack()

    btn_frame = tk.Frame(win, bg=colors["bg"])
    btn_frame.pack(pady=(0, 18), padx=18)

    def choose(value):
        result["value"] = value
        win.destroy()

    styled_button(btn_frame, "Save", lambda: choose(True), colors).pack(side="left", padx=4)
    styled_button(btn_frame, "Don't Save", lambda: choose(False), colors).pack(side="left", padx=4)
    styled_button(btn_frame, "Cancel", lambda: choose(None), colors).pack(side="left", padx=4)

    win.protocol("WM_DELETE_WINDOW", lambda: choose(None))
    win.bind("<Escape>", lambda e: choose(None))

    center_on_parent(win, app.root)
    win.grab_set()
    win.wait_window()
    return result["value"]


def show_error(app, title, message):
    win, colors = _make_dialog(app, title)

    header = tk.Frame(win, bg=colors["bg"])
    header.pack(padx=24, pady=(20, 8), fill="x")
    tk.Label(header, text="⚠", bg=colors["bg"], fg=colors["accent"],
             font=("", 18)).pack(side="left", padx=(0, 10))
    tk.Label(header, text=message, bg=colors["bg"], fg=colors["fg"],
             wraplength=300, justify="left").pack(side="left")

    btn_frame = tk.Frame(win, bg=colors["bg"])
    btn_frame.pack(pady=(4, 18))
    styled_button(btn_frame, "OK", win.destroy, colors, width=10).pack()

    win.protocol("WM_DELETE_WINDOW", win.destroy)
    win.bind("<Escape>", lambda e: win.destroy())
    win.bind("<Return>", lambda e: win.destroy())

    center_on_parent(win, app.root)
    win.grab_set()
    win.wait_window()


def show_info(app, title, message):
    win, colors = _make_dialog(app, title)

    tk.Label(win, text=message, bg=colors["bg"], fg=colors["fg"],
             wraplength=320, justify="left", padx=24, pady=20).pack()

    btn_frame = tk.Frame(win, bg=colors["bg"])
    btn_frame.pack(pady=(0, 18))
    styled_button(btn_frame, "OK", win.destroy, colors, width=10).pack()

    win.protocol("WM_DELETE_WINDOW", win.destroy)
    win.bind("<Escape>", lambda e: win.destroy())
    win.bind("<Return>", lambda e: win.destroy())

    center_on_parent(win, app.root)
    win.grab_set()
    win.wait_window()


# ================= FILE DIALOGS ================= #
def _list_directory(path):
    try:
        entries = os.listdir(path)
    except OSError:
        entries = []
    dirs = sorted(
        (e for e in entries if not e.startswith(".") and os.path.isdir(os.path.join(path, e))),
        key=str.lower,
    )
    files = sorted(
        (e for e in entries if not e.startswith(".") and os.path.isfile(os.path.join(path, e))),
        key=str.lower,
    )
    return dirs, files


def _list_windows_drives():
    if os.name != "nt":
        return []
    import string
    drives = []
    for letter in string.ascii_uppercase:
        drive = f"{letter}:\\"
        if os.path.exists(drive):
            drives.append(drive)
    return drives


def _run_file_dialog(app, mode, title, initial_filename="", defaultextension=""):
    colors = theme_colors(app.dark_mode)
    win = tk.Toplevel(app.root)
    win.title(title)
    win.geometry("520x420")
    win.transient(app.root)
    win.configure(bg=colors["bg"])

    result = {"path": None}
    state = {"cwd": os.path.abspath(getattr(app, "explorer_dir", None) or os.getcwd())}

    top = tk.Frame(win, bg=colors["bg"])
    top.pack(fill="x", padx=10, pady=(10, 4))

    def go_up():
        parent = os.path.dirname(state["cwd"].rstrip(os.sep))
        if parent and parent != state["cwd"]:
            state["cwd"] = parent
            refresh()

    styled_button(top, "⬆ Up", go_up, colors, width=5).pack(side="left")

    path_var = tk.StringVar()
    path_entry = tk.Entry(top, textvariable=path_var, bg=colors["button_bg"],
                           fg=colors["fg"], insertbackground=colors["fg"], relief="flat")
    path_entry.pack(side="left", fill="x", expand=True, padx=8, ipady=3)

    def go_to_typed_path(event=None):
        target = path_var.get().strip()
        if os.path.isdir(target):
            state["cwd"] = os.path.abspath(target)
            refresh()
        else:
            status_label.config(text="That folder doesn't exist.")

    path_entry.bind("<Return>", go_to_typed_path)

    drives = _list_windows_drives()
    if drives:
        drive_frame = tk.Frame(win, bg=colors["bg"])
        drive_frame.pack(fill="x", padx=10, pady=(0, 4))
        tk.Label(drive_frame, text="Drives:", bg=colors["bg"], fg=colors["fg"]).pack(side="left", padx=(0, 6))

        def jump_to_drive(drive):
            state["cwd"] = drive
            refresh()

        for drive in drives:
            label = drive.rstrip("\\")  # "C:\" -> "C:"
            styled_button(drive_frame, label, lambda d=drive: jump_to_drive(d), colors, width=4).pack(side="left", padx=2)

    list_frame = tk.Frame(win, bg=colors["bg"])
    list_frame.pack(fill="both", expand=True, padx=10)

    scrollbar = tk.Scrollbar(list_frame)
    scrollbar.pack(side="right", fill="y")

    listbox = tk.Listbox(
        list_frame, bg=colors["button_bg"], fg=colors["fg"],
        selectbackground=colors["select_bg"], selectforeground=colors["fg"],
        yscrollcommand=scrollbar.set, highlightthickness=0, bd=0, activestyle="none",
    )
    listbox.pack(side="left", fill="both", expand=True)
    scrollbar.config(command=listbox.yview)

    entry_frame = tk.Frame(win, bg=colors["bg"])
    entry_frame.pack(fill="x", padx=10, pady=(8, 0))
    tk.Label(entry_frame, text="File name:", bg=colors["bg"], fg=colors["fg"]).pack(side="left")
    filename_var = tk.StringVar(value=initial_filename)
    filename_entry = tk.Entry(entry_frame, textvariable=filename_var, bg=colors["button_bg"],
                               fg=colors["fg"], insertbackground=colors["fg"], relief="flat")
    filename_entry.pack(side="left", fill="x", expand=True, padx=6, ipady=3)

    status_label = tk.Label(win, text="", bg=colors["bg"], fg=colors["accent"])
    status_label.pack(fill="x", padx=10)

    btn_frame = tk.Frame(win, bg=colors["bg"])
    btn_frame.pack(pady=10)

    def refresh():
        listbox.delete(0, tk.END)
        path_var.set(state["cwd"])
        dirs, files = _list_directory(state["cwd"])
        for d in dirs:
            listbox.insert(tk.END, f"📁  {d}")
        for f in files:
            listbox.insert(tk.END, f"    {f}")
        status_label.config(text="")

    def entry_name_from_selection():
        selection = listbox.curselection()
        if not selection:
            return None, None
        raw = listbox.get(selection[0])
        is_dir = raw.startswith("📁")
        name = raw.split(maxsplit=1)[1] if is_dir else raw.strip()
        return name, is_dir

    def on_double_click(event=None):
        name, is_dir = entry_name_from_selection()
        if name is None:
            return
        if is_dir:
            state["cwd"] = os.path.join(state["cwd"], name)
            refresh()
        else:
            filename_var.set(name)
            confirm()

    def on_select(event=None):
        name, is_dir = entry_name_from_selection()
        if name is not None and not is_dir:
            filename_var.set(name)

    def confirm():
        name = filename_var.get().strip()
        if not name:
            status_label.config(text="Enter a file name.")
            return
        if mode == "save" and defaultextension and "." not in os.path.basename(name):
            name += defaultextension
        full = os.path.join(state["cwd"], name)
        if os.path.isdir(full):
            state["cwd"] = full
            refresh()
            return
        if mode == "open" and not os.path.isfile(full):
            status_label.config(text="That file doesn't exist.")
            return
        result["path"] = full
        win.destroy()

    def cancel():
        result["path"] = None
        win.destroy()

    listbox.bind("<Double-Button-1>", on_double_click)
    listbox.bind("<<ListboxSelect>>", on_select)
    filename_entry.bind("<Return>", lambda e: confirm())
    win.bind("<Escape>", lambda e: cancel())

    action_label = "Open" if mode == "open" else "Save"
    styled_button(btn_frame, action_label, confirm, colors, width=10).pack(side="left", padx=4)
    styled_button(btn_frame, "Cancel", cancel, colors, width=10).pack(side="left", padx=4)

    refresh()
    win.protocol("WM_DELETE_WINDOW", cancel)
    center_on_parent(win, app.root)
    win.grab_set()
    (filename_entry if mode == "save" else listbox).focus_set()
    win.wait_window()
    return result["path"]


def ask_open_filename(app):
    return _run_file_dialog(app, "open", "Open File")


def ask_save_filename(app, defaultextension=".txt", initial_filename="untitled.txt"):
    return _run_file_dialog(app, "save", "Save As",
                             initial_filename=initial_filename, defaultextension=defaultextension)
