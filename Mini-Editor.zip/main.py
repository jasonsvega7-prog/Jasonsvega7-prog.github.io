import os
import tkinter as tk

from app import TextEditor


def main():
    root = tk.Tk()
    assets_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    icon_path = os.path.join(assets_dir,"icon.png")
    
    if os.path.exists(icon_path):
        icon_img = tk.PhotoImage(file=icon_path)
        root.iconphoto(True, icon_img)
        root._icon_img_ref = icon_img
        TextEditor(root)
        root.mainloop()


if __name__ == "__main__":
    main()
