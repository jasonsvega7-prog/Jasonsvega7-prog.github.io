import re
import tkinter as tk


class FindReplaceDialog: 
    def __init__(self, app):
        self.app = app
        self.window = tk.Toplevel(app.root)
        self.window.title("Find & Replace")
        self.window.geometry("360x230")
        self.window.protocol("WM_DELETE_WINDOW", self._on_close)

        self.find_label = tk.Label(self.window, text="Find")
        self.find_label.pack(anchor="w", padx=10)
        self.find_entry = tk.Entry(self.window)
        self.find_entry.pack(fill="x", padx=10)

        self.replace_label = tk.Label(self.window, text="Replace")
        self.replace_label.pack(anchor="w", padx=10)
        self.replace_entry = tk.Entry(self.window)
        self.replace_entry.pack(fill="x", padx=10)

        self.match_case_var = tk.BooleanVar(value=True)
        self.match_case_check = tk.Checkbutton(self.window, text="Match case", variable=self.match_case_var)
        self.match_case_check.pack(anchor="w", padx=10, pady=(4, 0))

        self.button_frame = tk.Frame(self.window)
        self.button_frame.pack(pady=10)
        self.find_next_btn = tk.Button(self.button_frame, text="Find Next", command=self.find_next)
        self.find_next_btn.pack(side="left", padx=5)
        self.replace_btn = tk.Button(self.button_frame, text="Replace", command=self.replace)
        self.replace_btn.pack(side="left", padx=5)
        self.replace_all_btn = tk.Button(self.button_frame, text="Replace All", command=self.replace_all)
        self.replace_all_btn.pack(side="left", padx=5)

        self.status_label = tk.Label(self.window, text="", fg="blue")
        self.status_label.pack(pady=5)

        self.find_entry.focus_set()
        self.apply_theme(app.dark_mode)

    def _on_close(self):
        self.window.destroy()
        self.app.find_dialog = None

    def focus(self):
        self.window.lift()
        self.window.focus_force()
        self.find_entry.focus_set()

    def find_next(self):
        editor = self.app.get_current_editor()
        if editor is None:
            return
        text = editor["text"]
        search = self.find_entry.get()
        if not search:
            return
        nocase = not self.match_case_var.get()
        start = text.index(tk.INSERT)
        pos = text.search(search, start, stopindex=tk.END, nocase=nocase)
        if not pos:
            pos = text.search(search, "1.0", stopindex=tk.END, nocase=nocase)  # wrap around
            if not pos:
                self.status_label.config(text="No matches found.")
                return
        end = text.index(f"{pos}+{len(search)}c")
        text.tag_remove("found", "1.0", tk.END)
        text.tag_add("found", pos, end)
        text.mark_set(tk.INSERT, end)
        text.see(pos)
        self.status_label.config(text="")

    def replace(self):
        editor = self.app.get_current_editor()
        if editor is None:
            return
        text = editor["text"]
        if not text.tag_ranges("found"):
            self.find_next()
            return
        replacement = self.replace_entry.get()
        start, end = text.tag_ranges("found")
        text.delete(start, end)
        text.insert(start, replacement)
        text.tag_remove("found", "1.0", tk.END)

    def replace_all(self):
        editor = self.app.get_current_editor()
        if editor is None:
            return
        text = editor["text"]
        search = self.find_entry.get()
        replacement = self.replace_entry.get()
        if not search:
            return

        content = text.get("1.0", "end-1c")
        flags = 0 if self.match_case_var.get() else re.IGNORECASE
        pattern = re.compile(re.escape(search), flags)
        new_content, count = pattern.subn(lambda m: replacement, content)

        if count:
            text.delete("1.0", tk.END)
            text.insert("1.0", new_content)
            self.status_label.config(text=f"Replaced {count} occurrence(s).")
        else:
            self.status_label.config(text="No matches found.")

    def apply_theme(self, dark_mode):
        bg, fg = ("#1e1e1e", "white") if dark_mode else ("white", "black")

        self.window.config(bg=bg)
        self.button_frame.config(bg=bg)
        self.find_label.config(bg=bg, fg=fg)
        self.replace_label.config(bg=bg, fg=fg)
        self.match_case_check.config(bg=bg, fg=fg, selectcolor=bg, activebackground=bg, activeforeground=fg)
        self.status_label.config(bg=bg, fg="skyblue" if dark_mode else "blue")

        entry_bg = "#252526" if dark_mode else "white"
        self.find_entry.config(bg=entry_bg, fg=fg, insertbackground=fg)
        self.replace_entry.config(bg=entry_bg, fg=fg, insertbackground=fg)

        self.find_next_btn.config(bg=bg, fg=fg)
        self.replace_btn.config(bg=bg, fg=fg)
        self.replace_all_btn.config(bg=bg, fg=fg)
