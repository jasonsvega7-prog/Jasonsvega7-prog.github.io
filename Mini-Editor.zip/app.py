import os
import tkinter as tk
from tkinter import ttk

import dialogs
import editor_tab
import menu
import theme
import syntax
from find_replace import FindReplaceDialog
from font_picker import open_font_picker

_LANGUAGE_DISPLAY_BY_KEY = {key: name for name, key in syntax.LANGUAGES.items()}
_LANGUAGE_DISPLAY_BY_KEY[None] = "Plain Text"


class TextEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Mini VS Code Editor")
        self.root.geometry("1050x650")

        self.current_font = "DejaVu Sans"
        self.font_size = 12
        self.dark_mode = False
        self.untitled_count = 0
        self.find_dialog = None
        self.explorer_dir = os.path.abspath(os.getcwd())

        self.tabs = {}

        self.style = ttk.Style()
        self.style.theme_use("clam")

        menu.build_menu(self)
        self._build_layout()

        self.new_file()
        theme.apply_light_theme(self)

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        menu.bind_shortcuts(self)

    # ================= LAYOUT ================= #
    def _build_layout(self):
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(self.main_frame, width=200, bg="#1e1e1e")
        self.sidebar.pack(side="left", fill="y")

        self.explorer_header = tk.Frame(self.sidebar, bg="#1e1e1e")
        self.explorer_header.pack(fill="x")

        self.explorer_label = tk.Label(self.explorer_header, text="Explorer", bg="#1e1e1e", fg="white")
        self.explorer_label.pack(side="left", ipady=5, padx=(8, 0))

        self.refresh_btn = tk.Button(self.explorer_header, text="⟳", command=self.load_files,
                                      relief="flat", bd=0)
        self.refresh_btn.pack(side="right", padx=4)

        self.file_list = tk.Listbox(self.sidebar)
        self.file_list.pack(fill="both", expand=True)
        self.load_files()
        self.file_list.bind("<Double-Button-1>", self.open_from_list)

        self.right_side = tk.Frame(self.main_frame)
        self.right_side.pack(side="right", fill="both", expand=True)

        self.header = tk.Frame(self.right_side)
        self.header.pack(side="top", fill="x")

        self.menu_left = tk.Frame(self.header)
        self.menu_left.pack(side="left", padx=44)

        self.new_btn = tk.Button(self.menu_left, text="New", command=self.new_file, font=("Arial",12))
        self.new_btn.pack(side="left")
        self.open_btn = tk.Button(self.menu_left, text="Open", command=self.open_file, font=("Arial",12))
        self.open_btn.pack(side="left")
        self.save_btn = tk.Button(self.menu_left, text="Save", command=self.save_file, font=("Arial",12))
        self.save_btn.pack(side="left")
        self.font_btn = tk.Button(self.menu_left, text="Font", command=self.choose_font, font=("Arial",12))
        self.font_btn.pack(side="left")
        self.theme_btn = tk.Button(self.menu_left, text="Theme", command=self.toggle_dark_mode, font=("Arial",12))
        self.theme_btn.pack(side="left")
        self.find_btn = tk.Button(self.menu_left, text="Find", command=self.find_replace_window, font=("Arial",12))
        self.find_btn.pack(side="left")

        self.toolbar = tk.Frame(self.header)
        self.toolbar.pack(side="right", padx=(0, 14))

        self.decrease_button = tk.Button(self.toolbar, text="-", command=self.decrease_font_size, width=2, font=("Arial",12))
        self.decrease_button.pack(side="left")
        self.size_label = tk.Label(self.toolbar, text=str(self.font_size), width=4, font=("Arial",12))
        self.size_label.pack(side="left")
        self.increase_button = tk.Button(self.toolbar, text="+", command=self.increase_font_size, width=2, font=("Arial",12))
        self.increase_button.pack(side="left")

        self.notebook = ttk.Notebook(self.right_side)
        self.notebook.pack(fill="both", expand=True)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        self.notebook.bind("<Button-2>", self._on_tab_middle_click)
        self.notebook.bind("<Button-3>", self._on_tab_right_click)

        self._tab_menu = tk.Menu(self.notebook, tearoff=0)
        self._tab_menu.add_command(label="Close Tab", command=self.close_current_tab)

        self.status_bar = tk.Label(self.root, anchor="w", padx=8)
        self.status_bar.pack(side="bottom", fill="x")

    # ================= TAB MANAGEMENT ================= #
    def get_current_frame(self):
        tab_id = self.notebook.select()
        return self.notebook.nametowidget(tab_id) if tab_id else None

    def get_current_editor(self):
        frame = self.get_current_frame()
        return self.tabs.get(frame) if frame else None

    def create_editor(self, parent):
        return editor_tab.create_editor(self, parent)

    def on_text_modified(self, frame):
        editor = self.tabs.get(frame)
        if editor is None:
            return
        text = editor["text"]
        if text.edit_modified():
            editor["modified"] = True
            self._refresh_tab_title(frame)
            self._update_window_title()
            text.edit_modified(False)
        editor["update_line_numbers"]()
        editor_tab.schedule_highlight(self, editor)

    def _refresh_tab_title(self, frame):
        editor = self.tabs.get(frame)
        if editor is None:
            return
        name = os.path.basename(editor["file"]) if editor["file"] else editor.get("display_name", "Untitled")
        if editor["modified"]:
            name = "● " + name
        self.notebook.tab(frame, text=name)

    def _update_window_title(self):
        editor = self.get_current_editor()
        if editor is None:
            self.root.title("Mini VS Code Editor")
            return
        name = editor["file"] or editor.get("display_name", "Untitled")
        marker = "●  " if editor["modified"] else ""
        self.root.title(f"{marker}{name} — Mini VS Code Editor")

    def on_tab_changed(self, event=None):
        self._update_window_title()
        self.update_status_bar()
        editor = self.get_current_editor()
        if editor is not None and hasattr(self, "language_var"):
            self.language_var.set(_LANGUAGE_DISPLAY_BY_KEY.get(editor["language"], "Plain Text"))

    def new_file(self):
        self.untitled_count += 1
        display_name = "Untitled" if self.untitled_count == 1 else f"Untitled {self.untitled_count}"
        frame = tk.Frame(self.notebook)
        self.notebook.add(frame, text=display_name)
        self.notebook.select(frame)
        editor = self.create_editor(frame)
        editor["display_name"] = display_name
        self._update_window_title()

    def _on_tab_middle_click(self, event):
        try:
            index = self.notebook.index(f"@{event.x},{event.y}")
        except tk.TclError:
            return
        frame_name = self.notebook.tabs()[index]
        self.close_tab(self.notebook.nametowidget(frame_name))

    def _on_tab_right_click(self, event):
        try:
            index = self.notebook.index(f"@{event.x},{event.y}")
        except tk.TclError:
            return
        self.notebook.select(index)
        self._tab_menu.tk_popup(event.x_root, event.y_root)

    def close_current_tab(self):
        frame = self.get_current_frame()
        if frame is not None:
            self.close_tab(frame)

    def close_tab(self, frame):
        editor = self.tabs.get(frame)
        if editor is None:
            return

        if editor["modified"]:
            self.notebook.select(frame)
            name = editor["file"] or editor.get("display_name", "Untitled")
            choice = dialogs.ask_yes_no_cancel(self, "Unsaved changes", f"Save changes to {os.path.basename(name)}?")
            if choice is None:
                return
            if choice:
                self.save_file()
                if editor["modified"]:
                    return

        if editor["highlight_after_id"] is not None:
            self.root.after_cancel(editor["highlight_after_id"])

        self.notebook.forget(frame)
        del self.tabs[frame]

        if not self.tabs:
            self.new_file()

    # ================= FILE SYSTEM ================= #
    def load_files(self):
        self.file_list.delete(0, tk.END)
        try:
            entries = sorted(os.listdir(self.explorer_dir))
        except OSError:
            return
        for f in entries:
            path = os.path.join(self.explorer_dir, f)
            if os.path.isfile(path):
                self.file_list.insert(tk.END, f)

    def open_from_list(self, event=None):
        selection = self.file_list.curselection()
        if not selection:
            return
        filename = self.file_list.get(selection)
        self.open_file_by_name(os.path.join(self.explorer_dir, filename))

    def open_file(self):
        file = dialogs.ask_open_filename(self)
        if file:
            self.open_file_by_name(file)

    def open_file_by_name(self, file):
        for frame, editor in self.tabs.items():
            if editor["file"] and os.path.abspath(editor["file"]) == os.path.abspath(file):
                self.notebook.select(frame)
                return

        try:
            with open(file, "r", encoding="utf-8") as f:
                content = f.read()
        except (OSError, UnicodeDecodeError) as e:
            dialogs.show_error(self, "Could not open file", str(e))
            return

        frame = tk.Frame(self.notebook)
        self.notebook.add(frame, text=os.path.basename(file))
        self.notebook.select(frame)
        editor = self.create_editor(frame)

        editor["text"].insert("1.0", content)
        editor["text"].edit_modified(False)
        editor["modified"] = False
        editor["file"] = file
        editor["update_line_numbers"]()
        self._refresh_tab_title(frame)
        self._update_window_title()

        self.explorer_dir = os.path.dirname(os.path.abspath(file))
        self.load_files()

        language_key = syntax.detect_language(file)
        editor_tab.set_language(self, editor, language_key)
        if hasattr(self, "language_var"):
            self.language_var.set(_LANGUAGE_DISPLAY_BY_KEY.get(language_key, "Plain Text"))

    def save_file(self):
        editor = self.get_current_editor()
        if editor is None:
            return
        if editor["file"]:
            try:
                with open(editor["file"], "w", encoding="utf-8") as f:
                    f.write(editor["text"].get("1.0", "end-1c"))
            except OSError as e:
                dialogs.show_error(self, "Could not save file", str(e))
                return
            editor["modified"] = False
            self._refresh_tab_title(editor["frame"])
            self._update_window_title()
        else:
            self.save_as()

    def save_as(self):
        editor = self.get_current_editor()
        if editor is None:
            return
        suggested = os.path.basename(editor["file"]) if editor["file"] else "untitled.txt"
        file = dialogs.ask_save_filename(self, initial_filename=suggested)
        if file:
            editor["file"] = file
            self.save_file()
            self.explorer_dir = os.path.dirname(os.path.abspath(file))
            self.load_files()
            language_key = syntax.detect_language(file)
            editor_tab.set_language(self, editor, language_key)
            if hasattr(self, "language_var"):
                self.language_var.set(_LANGUAGE_DISPLAY_BY_KEY.get(language_key, "Plain Text"))

    def on_close(self):
        for frame, editor in list(self.tabs.items()):
            if editor["modified"]:
                self.notebook.select(frame)
                name = editor["file"] or editor.get("display_name", "Untitled")
                choice = dialogs.ask_yes_no_cancel(
                    self, "Unsaved changes", f"Save changes to {os.path.basename(name)} before closing?"
                )
                if choice is None:
                    return
                if choice:
                    self.save_file()
                    if editor["modified"]:
                        return
        self.root.destroy()

    # ================= LANGUAGE ================= #
    def set_current_tab_language(self, language_key):
        editor = self.get_current_editor()
        if editor is None:
            return
        editor_tab.set_language(self, editor, language_key)

    # ================= STATUS BAR ================= #
    def update_status_bar(self, event=None):
        editor = self.get_current_editor()
        if editor is None:
            return
        line, col = editor["text"].index(tk.INSERT).split(".")
        path = editor["file"] or editor.get("display_name", "Untitled")
        self.status_bar.config(text=f"{path}    Ln {line}, Col {int(col) + 1}")

    # ================= FONT ================= #
    def increase_font_size(self):
        self.font_size += 1
        self.update_font()

    def decrease_font_size(self):
        if self.font_size > 6:
            self.font_size -= 1
            self.update_font()

    def update_font(self):
        for editor in self.tabs.values():
            editor["text"].config(font=(self.current_font, self.font_size))
            editor["line_numbers"].config(font=(self.current_font, self.font_size))
        self.size_label.config(text=str(self.font_size))

    def choose_font(self):
        open_font_picker(self)

    # ================= FIND & REPLACE ================= #
    def find_replace_window(self):
        if self.find_dialog is not None and self.find_dialog.window.winfo_exists():
            self.find_dialog.focus()
            return
        self.find_dialog = FindReplaceDialog(self)

    # ================= THEME ================= #
    def toggle_dark_mode(self):
        theme.toggle_dark_mode(self)
