import tkinter as tk
import tkinter.font as tkfont

from dialogs import theme_colors, styled_button, center_on_parent


def open_font_picker(app):
    colors = theme_colors(app.dark_mode)

    win = tk.Toplevel(app.root)
    win.title("Fonts")
    win.geometry("300x420")
    win.transient(app.root)
    win.configure(bg=colors["bg"])

    filter_entry = tk.Entry(win, bg=colors["button_bg"], fg=colors["fg"],
                             insertbackground=colors["fg"], relief="flat")
    filter_entry.pack(fill="x", padx=8, pady=(8, 4), ipady=3)

    list_frame = tk.Frame(win, bg=colors["bg"])
    list_frame.pack(fill="both", expand=True, padx=8)

    scrollbar = tk.Scrollbar(list_frame)
    scrollbar.pack(side="right", fill="y")

    listbox = tk.Listbox(list_frame, bg=colors["button_bg"], fg=colors["fg"],
                          selectbackground=colors["select_bg"], selectforeground=colors["fg"],
                          yscrollcommand=scrollbar.set, highlightthickness=0, bd=0, activestyle="none")
    listbox.pack(side="left", fill="both", expand=True)
    scrollbar.config(command=listbox.yview)

    all_fonts = sorted(tkfont.families())

    def populate(filter_text=""):
        listbox.delete(0, tk.END)
        for family in all_fonts:
            if filter_text.lower() in family.lower():
                listbox.insert(tk.END, family)

    populate()
    filter_entry.bind("<KeyRelease>", lambda e: populate(filter_entry.get()))

    def select():
        selection = listbox.curselection()
        if selection:
            app.current_font = listbox.get(selection[0])
            app.update_font()
            win.destroy()

    listbox.bind("<Double-Button-1>", lambda e: select())
    filter_entry.bind("<Return>", lambda e: select())
    win.bind("<Escape>", lambda e: win.destroy())

    styled_button(win, "Select", select, colors, width=10).pack(fill="x", padx=8, pady=8)

    center_on_parent(win, app.root)
    filter_entry.focus_set()
