import re
import tkinter as tk
from tkinter import ttk

import syntax
from theme import apply_syntax_colors

HIGHLIGHT_DEBOUNCE_MS = 300

_TRAILING_WHITESPACE = re.compile(r"\s+$")
_TRAILING_WORD = re.compile(r"\w+$")
_TRAILING_PUNCT = re.compile(r"[^\w\s]+$")


def _delete_word_backward(text_widget, event=None):
    index = text_widget.index(tk.INSERT)
    line, col = index.split(".")
    col = int(col)

    if col == 0:
        line_num = int(line)
        if line_num > 1:
            text_widget.delete(f"{line_num - 1}.end", index)
        return "break"

    line_text = text_widget.get(f"{line}.0", index)

    ws_match = _TRAILING_WHITESPACE.search(line_text)
    core_end = ws_match.start() if ws_match else len(line_text)
    core = line_text[:core_end]

    if core:
        word_match = _TRAILING_WORD.search(core)
        if word_match:
            start = word_match.start()
        else:
            punct_match = _TRAILING_PUNCT.search(core)
            start = punct_match.start() if punct_match else 0
    else:
        start = 0

    text_widget.delete(f"{line}.{start}", index)
    return "break"


def create_editor(app, parent):
    line_numbers = tk.Text(parent, width=4, padx=5, takefocus=0, border=0, state="disabled",
                            wrap="none", font=(app.current_font, app.font_size))
    line_numbers.pack(side="left", fill="y")

    scrollbar = ttk.Scrollbar(parent, orient="vertical")
    scrollbar.pack(side="right", fill="y")

    h_scrollbar = ttk.Scrollbar(parent, orient="horizontal")
    h_scrollbar.pack(side="bottom", fill="x")

    text = tk.Text(parent, wrap="none", xscrollcommand=h_scrollbar.set,
                    font=(app.current_font, app.font_size), undo=True)
    text.pack(side="left", fill="both", expand=True)
    text.tag_configure("found", background="yellow", foreground="black")

    def on_scroll(*args):
        text.yview(*args)
        line_numbers.yview(*args)

    def sync_scroll(*args):
        scrollbar.set(*args)
        line_numbers.yview_moveto(args[0])

    def update_line_numbers(event=None):
        line_numbers.config(state="normal")
        line_numbers.delete("1.0", tk.END)
        total_lines = int(text.index("end-1c").split(".")[0])
        line_numbers.insert("1.0", "\n".join(str(i) for i in range(1, total_lines + 1)))
        line_numbers.config(state="disabled")

    text.config(yscrollcommand=sync_scroll)
    scrollbar.config(command=on_scroll)
    h_scrollbar.config(command=text.xview)

    editor = {
        "frame": parent,
        "text": text,
        "line_numbers": line_numbers,
        "scrollbar": scrollbar,
        "h_scrollbar": h_scrollbar,
        "file": None,
        "modified": False,
        "language": None,
        "highlight_after_id": None,
        "update_line_numbers": update_line_numbers,
    }
    app.tabs[parent] = editor

    text.bind("<<Modified>>", lambda e, f=parent: app.on_text_modified(f))
    text.bind("<KeyRelease>", app.update_status_bar)
    text.bind("<ButtonRelease-1>", app.update_status_bar)
    text.bind("<Control-BackSpace>", lambda e: _delete_word_backward(text, e))

    update_line_numbers()
    apply_syntax_colors(text, dark_mode=app.dark_mode)
    if app.dark_mode:
        text.config(bg="#1e1e1e", fg="white", insertbackground="white")
        line_numbers.config(bg="#2d2d30", fg="lightgray")
    else:
        text.config(bg="white", fg="black", insertbackground="black")
        line_numbers.config(bg="#eeeeee", fg="black")

    return editor


def set_language(app, editor, language_key):
    editor["language"] = language_key
    schedule_highlight(app, editor, immediate=True)


def schedule_highlight(app, editor, immediate=False):
    if editor["highlight_after_id"] is not None:
        app.root.after_cancel(editor["highlight_after_id"])
        editor["highlight_after_id"] = None

    def run():
        editor["highlight_after_id"] = None
        highlighter = syntax.get_highlighter(editor["language"])
        if highlighter is not None:
            highlighter.highlight(editor["text"])
        else:
            for tag in syntax.ALL_TAG_NAMES:
                editor["text"].tag_remove(tag, "1.0", "end")

    if immediate:
        run()
    else:
        editor["highlight_after_id"] = app.root.after(HIGHLIGHT_DEBOUNCE_MS, run)
