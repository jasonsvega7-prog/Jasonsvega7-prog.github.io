from .base import Highlighter


class HtmlHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"<!--[\s\S]*?-->"),
        ("keyword", r"<!DOCTYPE[^>]*>"),
        ("string", r"\"[^\"]*\"|'[^']*'"),
        ("tag", r"</?[A-Za-z][\w:-]*"),
        ("attribute", r"\b[A-Za-z_:][-\w:.]*(?=\s*=)"),
    ]
