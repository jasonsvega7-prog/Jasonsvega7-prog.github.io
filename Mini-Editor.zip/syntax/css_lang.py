from .base import Highlighter


class CssHighlighter(Highlighter):
    """A simplified CSS highlighter - it recognizes comments, strings,
    at-rules, class/id selectors, property names, and numeric values with
    units. It isn't a full CSS parser (e.g. pseudo-selectors like `a:hover`
    can be mis-tagged), which is a fine tradeoff for an editor highlighter."""

    TOKENS = [
        ("comment", r"/\*[\s\S]*?\*/"),
        ("string", r'"[^"]*"|\'[^\']*\''),
        ("keyword", r"@[A-Za-z-]+|!important"),
        ("tag", r"\.[A-Za-z_-][\w-]*|#[A-Za-z_-][\w-]*"),  # class / id selectors
        ("attribute", r"\b[a-zA-Z-]+(?=\s*:)"),             # property names
        ("number", r"\b\d+\.?\d*(?:px|em|rem|%|vh|vw|pt|s|ms|deg)?\b"),
    ]
