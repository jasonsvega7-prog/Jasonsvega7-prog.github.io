from .base import Highlighter

KEYWORDS = [
    "break", "case", "catch", "class", "const", "continue", "debugger",
    "default", "delete", "do", "else", "export", "extends", "finally", "for",
    "function", "if", "import", "in", "instanceof", "let", "new", "return",
    "super", "switch", "this", "throw", "try", "typeof", "var", "void",
    "while", "with", "yield", "async", "await", "static", "get", "set",
    "true", "false", "null", "undefined",
]

BUILTINS = [
    "console", "document", "window", "Math", "JSON", "Object", "Array",
    "String", "Number", "Boolean", "Promise", "Map", "Set", "Symbol",
    "fetch", "setTimeout", "setInterval", "require", "module", "exports",
]


class JavaScriptHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"//[^\n]*|/\*[\s\S]*?\*/"),
        ("string", r"`(?:\\.|[^`\\])*`"
                   r"|'(?:\\.|[^'\\\n])*'|\"(?:\\.|[^\"\\\n])*\""),
        ("definition", r"(?<=\bfunction )\w+|(?<=\bclass )\w+"),
        ("number", r"\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][+-]?\d+)?\b"),
        ("keyword", r"\b(?:" + "|".join(KEYWORDS) + r")\b"),
        ("builtin", r"\b(?:" + "|".join(BUILTINS) + r")\b"),
    ]
