from .base import Highlighter

KEYWORDS = [
    "False", "None", "True", "and", "as", "assert", "async", "await", "break",
    "class", "continue", "def", "del", "elif", "else", "except", "finally",
    "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal",
    "not", "or", "pass", "raise", "return", "try", "while", "with", "yield",
    "match", "case",
]

BUILTINS = [
    "print", "len", "range", "int", "str", "float", "bool", "list", "dict",
    "set", "tuple", "object", "type", "isinstance", "super", "self", "open",
    "enumerate", "zip", "map", "filter", "sorted", "reversed", "sum", "min",
    "max", "abs", "any", "all", "input", "iter", "next", "getattr", "setattr",
]


class PythonHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"#[^\n]*"),
        ("string", r"(?:[rRbBuUfF]{0,2})"
                   r"(?:'''[\s\S]*?'''|\"\"\"[\s\S]*?\"\"\""
                   r"|'(?:\\.|[^'\\\n])*'|\"(?:\\.|[^\"\\\n])*\")"),
        ("decorator", r"@[A-Za-z_][\w.]*"),
        ("definition", r"(?<=\bdef )\w+|(?<=\bclass )\w+"),
        ("number", r"\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][+-]?\d+)?\b"),
        ("keyword", r"\b(?:" + "|".join(KEYWORDS) + r")\b"),
        ("builtin", r"\b(?:" + "|".join(BUILTINS) + r")\b"),
    ]
