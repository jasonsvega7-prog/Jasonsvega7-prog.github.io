import re
from bisect import bisect_right


class Highlighter:
    
    TOKENS = [] 

    def __init__(self):
        pattern = "|".join(f"(?P<{tag}>{regex})" for tag, regex in self.TOKENS)
        self._pattern = re.compile(pattern)
        self.tag_names = [tag for tag, _ in self.TOKENS]

    def highlight(self, text_widget):
        content = text_widget.get("1.0", "end-1c")

        for tag in self.tag_names:
            text_widget.tag_remove(tag, "1.0", "end")

        line_lengths = [len(line) + 1 for line in content.split("\n")]
        line_starts = [0]
        for length in line_lengths:
            line_starts.append(line_starts[-1] + length)

        def offset_to_index(offset):
            line = bisect_right(line_starts, offset) - 1
            col = offset - line_starts[line]
            return f"{line + 1}.{col}"

        for match in self._pattern.finditer(content):
            kind = match.lastgroup
            if kind is None:
                continue
            start_index = offset_to_index(match.start())
            end_index = offset_to_index(match.end())
            text_widget.tag_add(kind, start_index, end_index)
