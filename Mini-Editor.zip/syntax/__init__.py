import os

from .python_lang import PythonHighlighter
from .javascript_lang import JavaScriptHighlighter
from .html_lang import HtmlHighlighter
from .csharp_lang import CSharpHighlighter
from .cpp_lang import CppHighlighter
from .css_lang import CssHighlighter
from .php_lang import PhpHighlighter

# Display name -> (internal key, highlighter class)
LANGUAGES = {
    "Python": "python",
    "JavaScript": "javascript",
    "HTML": "html",
    "CSS": "css",
    "PHP": "php",
    "C#": "csharp",
    "C++": "cpp",
    "Plain Text": None,
}

_HIGHLIGHTER_CLASSES = {
    "python": PythonHighlighter,
    "javascript": JavaScriptHighlighter,
    "html": HtmlHighlighter,
    "css": CssHighlighter,
    "php": PhpHighlighter,
    "csharp": CSharpHighlighter,
    "cpp": CppHighlighter,
}

_EXTENSION_MAP = {
    ".py": "python",
    ".pyw": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".html": "html",
    ".htm": "html",
    ".css": "css",
    ".php": "php",
    ".phtml": "php",
    ".cs": "csharp",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".h": "cpp",
    ".hpp": "cpp",
}

_instances = {}

ALL_TAG_NAMES = sorted({tag for cls in _HIGHLIGHTER_CLASSES.values() for tag, _ in cls.TOKENS})


def detect_language(filename):
    if not filename:
        return None
    _, ext = os.path.splitext(filename)
    return _EXTENSION_MAP.get(ext.lower())


def get_highlighter(language_key):
    if language_key is None:
        return None
    if language_key not in _instances:
        cls = _HIGHLIGHTER_CLASSES.get(language_key)
        if cls is None:
            return None
        _instances[language_key] = cls()
    return _instances[language_key]
