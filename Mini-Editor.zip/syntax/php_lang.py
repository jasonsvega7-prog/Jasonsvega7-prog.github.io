from .base import Highlighter

KEYWORDS = [
    "abstract", "and", "array", "as", "break", "callable", "case", "catch",
    "class", "clone", "const", "continue", "declare", "default", "do",
    "echo", "else", "elseif", "empty", "enddeclare", "endfor", "endforeach",
    "endif", "endswitch", "endwhile", "extends", "final", "finally", "fn",
    "for", "foreach", "function", "global", "goto", "if", "implements",
    "include", "include_once", "instanceof", "insteadof", "interface",
    "isset", "list", "match", "namespace", "new", "or", "print", "private",
    "protected", "public", "require", "require_once", "return", "static",
    "switch", "throw", "trait", "try", "unset", "use", "var", "while",
    "xor", "yield", "true", "false", "null",
]

BUILTINS = [
    "strlen", "count", "array_map", "array_filter", "array_merge", "isset",
    "empty", "var_dump", "print_r", "implode", "explode", "str_replace",
    "in_array", "json_encode", "json_decode", "sprintf", "preg_match",
]


class PhpHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"//[^\n]*|/\*[\s\S]*?\*/"),
        ("tag", r"<\?php|<\?=|\?>"),
        ("string", r'"(?:\\.|[^"\\])*"' r"|'(?:\\.|[^'\\])*'"),
        ("variable", r"\$[A-Za-z_]\w*"),
        ("number", r"\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][+-]?\d+)?\b"),
        ("keyword", r"\b(?:" + "|".join(KEYWORDS) + r")\b"),
        ("builtin", r"\b(?:" + "|".join(BUILTINS) + r")\b"),
    ]
