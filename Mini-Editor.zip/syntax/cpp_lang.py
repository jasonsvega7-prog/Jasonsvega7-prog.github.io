from .base import Highlighter

KEYWORDS = [
    "alignas", "alignof", "and", "asm", "auto", "bool", "break", "case",
    "catch", "char", "class", "const", "constexpr", "continue", "decltype",
    "default", "delete", "do", "double", "else", "enum", "explicit",
    "export", "extern", "false", "float", "for", "friend", "goto", "if",
    "inline", "int", "long", "mutable", "namespace", "new", "noexcept",
    "nullptr", "operator", "private", "protected", "public", "register",
    "return", "short", "signed", "sizeof", "static", "struct", "switch",
    "template", "this", "throw", "true", "try", "typedef", "typename",
    "union", "unsigned", "using", "virtual", "void", "volatile", "while",
]

BUILTINS = [
    "std", "cout", "cin", "endl", "string", "vector", "map", "set", "pair",
    "unique_ptr", "shared_ptr", "size_t", "nullptr_t",
]


class CppHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"//[^\n]*|/\*[\s\S]*?\*/"),
        ("preprocessor", r"#\s*\w+[^\n]*"),
        ("string", r'"(?:\\.|[^"\\\n])*"' r"|'(?:\\.|[^'\\\n])'"),
        ("definition", r"(?<=\bclass )\w+|(?<=\bstruct )\w+"),
        ("number", r"\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][+-]?\d+)?[fFlLuU]*\b"),
        ("keyword", r"\b(?:" + "|".join(KEYWORDS) + r")\b"),
        ("builtin", r"\b(?:" + "|".join(BUILTINS) + r")\b"),
    ]
