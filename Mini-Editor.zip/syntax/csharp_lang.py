from .base import Highlighter

KEYWORDS = [
    "abstract", "as", "base", "bool", "break", "byte", "case", "catch",
    "char", "checked", "class", "const", "continue", "decimal", "default",
    "delegate", "do", "double", "else", "enum", "event", "explicit",
    "extern", "finally", "fixed", "float", "for", "foreach", "goto", "if",
    "implicit", "in", "int", "interface", "internal", "is", "lock", "long",
    "namespace", "new", "null", "object", "operator", "out", "override",
    "params", "private", "protected", "public", "readonly", "ref", "return",
    "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string",
    "struct", "switch", "this", "throw", "true", "false", "try", "typeof",
    "uint", "ulong", "unchecked", "unsafe", "ushort", "using", "virtual",
    "void", "volatile", "while", "var", "async", "await", "get", "set",
]

BUILTINS = [
    "Console", "String", "List", "Dictionary", "IEnumerable", "Task",
    "Exception", "Convert", "Math", "DateTime", "Nullable",
]


class CSharpHighlighter(Highlighter):
    TOKENS = [
        ("comment", r"//[^\n]*|/\*[\s\S]*?\*/"),
        ("string", r'@"(?:""|[^"])*"'
                   r'|"(?:\\.|[^"\\\n])*"'
                   r"|'(?:\\.|[^'\\\n])'"),
        ("decorator", r"\[[A-Za-z_][\w.]*\]"),
        ("definition", r"(?<=\bclass )\w+|(?<=\binterface )\w+|(?<=\bstruct )\w+"),
        ("number", r"\b0[xX][0-9a-fA-F]+\b|\b\d+\.?\d*(?:[eE][+-]?\d+)?[fFdDmMuUlL]*\b"),
        ("keyword", r"\b(?:" + "|".join(KEYWORDS) + r")\b"),
        ("builtin", r"\b(?:" + "|".join(BUILTINS) + r")\b"),
    ]
