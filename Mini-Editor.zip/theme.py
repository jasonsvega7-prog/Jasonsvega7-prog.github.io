SYNTAX_COLORS = {
    "light": {
        "comment": "#6a9955",
        "string": "#a31515",
        "number": "#098658",
        "keyword": "#0000ff",
        "builtin": "#795e26",
        "definition": "#795e26",
        "decorator": "#af00db",
        "preprocessor": "#af00db",
        "tag": "#800000",
        "attribute": "#ff0000",
        "variable": "#001080",
    },
    "dark": {
        "comment": "#6a9955",
        "string": "#ce9178",
        "number": "#b5cea8",
        "keyword": "#569cd6",
        "builtin": "#dcdcaa",
        "definition": "#dcdcaa",
        "decorator": "#c586c0",
        "preprocessor": "#c586c0",
        "tag": "#569cd6",
        "attribute": "#9cdcfe",
        "variable": "#9cdcfe",
    },
}


def apply_syntax_colors(text_widget, dark_mode):
    palette = SYNTAX_COLORS["dark"] if dark_mode else SYNTAX_COLORS["light"]
    for tag, color in palette.items():
        text_widget.tag_configure(tag, foreground=color)
    text_widget.tag_raise("found")


def apply_light_theme(app):
    app.root.configure(bg="white")

    app.style.configure("Light.Vertical.TScrollbar", background="#f0f0f0",
                         troughcolor="white", bordercolor="#f0f0f0", arrowcolor="black")
    app.style.configure("Light.Horizontal.TScrollbar", background="#f0f0f0",
                         troughcolor="white", bordercolor="#f0f0f0", arrowcolor="black")

    for editor in app.tabs.values():
        editor["scrollbar"].configure(style="Light.Vertical.TScrollbar")
        editor["h_scrollbar"].configure(style="Light.Horizontal.TScrollbar")
        editor["text"].config(bg="white", fg="black", insertbackground="black")
        editor["line_numbers"].config(bg="#eeeeee", fg="black")
        editor["frame"].config(bg="white")
        apply_syntax_colors(editor["text"], dark_mode=False)

    app.sidebar.config(bg="#f0f0f0")
    app.explorer_header.config(bg="#f0f0f0")
    app.header.config(bg="#f0f0f0")
    app.menu_left.config(bg="#f0f0f0")
    app.toolbar.config(bg="#f0f0f0")
    app.right_side.config(bg="white")

    app.file_list.config(bg="white", fg="black")
    app.explorer_label.config(bg="#f0f0f0", fg="black")
    app.size_label.config(bg="#f0f0f0", fg="black")
    app.status_bar.config(bg="#f0f0f0", fg="black")
    app.refresh_btn.config(bg="#f0f0f0", fg="black", activebackground="#d9d9d9")

    buttons = [app.new_btn, app.open_btn, app.save_btn, app.font_btn,
               app.theme_btn, app.decrease_button, app.increase_button, app.find_btn]
    for btn in buttons:
        btn.config(bg="#f0f0f0", fg="black", activebackground="#d9d9d9", activeforeground="black", relief="flat", bd=0, highlightthickness=0)

    app.style.configure("TNotebook", background="#f0f0f0", borderwidth=0)
    app.style.configure("TNotebook.Tab", background="#d9d9d9", foreground="black", padding=(10, 5))
    app.style.map("TNotebook.Tab",
                  background=[("selected", "white"), ("!selected", "#d9d9d9")],
                  foreground=[("selected", "black"), ("!selected", "black")])

    if app.find_dialog is not None:
        app.find_dialog.apply_theme(dark_mode=False)


def apply_dark_theme(app):
    bg, panel, button = "#1e1e1e", "#2d2d30", "#3c3c3c"

    app.style.configure("Dark.Vertical.TScrollbar", gripcount=0, background="#8a8a8a",
                         troughcolor=panel, bordercolor=panel, arrowcolor="#000000")
    app.style.map("Dark.Vertical.TScrollbar",
                  background=[("active", "#ababab"), ("!active", "#ababab")],
                  troughcolor=[("!active", panel)],
                  arrowcolor=[("!active", "#ffffff"), ("active", "#ffffff")])

    app.style.configure("Dark.Horizontal.TScrollbar", gripcount=0, background="#ababab",
                         troughcolor=panel, bordercolor=panel, arrowcolor="#000000")
    app.style.map("Dark.Horizontal.TScrollbar",
                  background=[("active", "#ababab"), ("!active", "#ababab")],
                  troughcolor=[("!active", panel)],
                  arrowcolor=[("!active", "#ffffff"), ("active", "#ffffff")])

    for editor in app.tabs.values():
        editor["scrollbar"].configure(style="Dark.Vertical.TScrollbar")
        editor["h_scrollbar"].configure(style="Dark.Horizontal.TScrollbar")
        editor["text"].config(bg=bg, fg="white", insertbackground="white")
        editor["line_numbers"].config(bg=panel, fg="lightgray")
        editor["frame"].config(bg=bg)
        apply_syntax_colors(editor["text"], dark_mode=True)

    app.root.configure(bg=bg)
    app.sidebar.config(bg=panel)
    app.explorer_header.config(bg=panel)
    app.header.config(bg=panel)
    app.menu_left.config(bg=panel)
    app.toolbar.config(bg=panel)
    app.right_side.config(bg=bg)

    app.file_list.config(bg=bg, fg="white")
    app.explorer_label.config(bg=panel, fg="white")
    app.size_label.config(bg=panel, fg="white")
    app.status_bar.config(bg=panel, fg="white")
    app.refresh_btn.config(bg=panel, fg="white", activebackground="#555555")

    buttons = [app.new_btn, app.open_btn, app.save_btn, app.font_btn,
               app.theme_btn, app.decrease_button, app.increase_button, app.find_btn]
    for btn in buttons:
        btn.config(bg=panel, fg="white", activebackground="#555555", activeforeground="white",
                   relief="flat", bd=0, highlightthickness=0)

    app.style.configure("TNotebook", background=bg, borderwidth=0)
    app.style.configure("TNotebook.Tab", background=button, foreground="white", padding=(10, 5))
    app.style.map("TNotebook.Tab",
                  background=[("selected", bg), ("!selected", button)],
                  foreground=[("selected", "white"), ("!selected", "white")])

    if app.find_dialog is not None:
        app.find_dialog.apply_theme(dark_mode=True)


def toggle_dark_mode(app):
    app.dark_mode = not app.dark_mode
    if app.dark_mode:
        apply_dark_theme(app)
    else:
        apply_light_theme(app)
